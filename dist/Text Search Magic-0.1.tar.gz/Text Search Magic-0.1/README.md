# Text search


## Prerequisits
- Python3 needs to be installed on your machine. You can download the binary for your OS from [here](https://www.python.org/downloads/)

## Running the app

1. cd to the directory where requirements.txt is located.
2. run `% pip install -r requirements.txt` in your shell.
3. run `% python -m run.py <path to a folder containing text files>`
